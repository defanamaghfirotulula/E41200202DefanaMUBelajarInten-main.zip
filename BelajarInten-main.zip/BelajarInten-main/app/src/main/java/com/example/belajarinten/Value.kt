package com.example.belajarinten

object Value {
    const val MESSEGE = "messege"
}